GNU/Linux distributions created and managed with PDK include:

* [64 Studio](http://www.64studio.com/)

* [Lionstracs Mediastation](http://www.lionstracs.com/)

* [Trinity Audio Group Indamixx](http://www.indamixx.com/)

* [MythOS Ares](http://pdk.64studio.com/projects/ares/) and [MythOS Eros](http://pdk.64studio.com/projects/eros/) 
