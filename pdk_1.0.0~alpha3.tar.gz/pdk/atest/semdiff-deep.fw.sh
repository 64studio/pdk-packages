
pdk workspace create semdiff-deep
pushd semdiff-deep

mkdir channel-1
cp \
    ${PACKAGES}/emacs-defaults_1.1_all.deb \
    ${PACKAGES}/emacs-defaults_1.1.dsc \
    ${PACKAGES}/emacs-defaults_1.1.tar.gz \
    channel-1

cat >etc/channels.xml <<EOF
<?xml version="1.0"?>
<channels>
  <channel-1>
    <type>dir</type>
    <path>channel-1</path>
  </channel-1>
</channels>
EOF

pdk channel update



mkdir vc

cat >vc/a.xml <<EOF
<?xml version="1.0"?>
<component>
  <contents>
    <component>vc/b.xml</component>
  </contents>
</component>
EOF

cat >vc/b.xml <<EOF
<?xml version="1.0"?>
<component>
  <contents>
    <dsc>emacs-defaults</dsc>
  </contents>
</component>
EOF

pdk commit -m 'before' vc/a.xml vc/b.xml

cat >vc/b.xml <<EOF
<?xml version="1.0"?>
<component>
  <contents>
    <dsc>emacs-defaults</dsc>
  </contents>
</component>
EOF

pdk resolve vc/b.xml
pdk semdiff -m vc/a.xml | LANG=C sort >2file.diff

diff -u - 2file.diff <<EOF
add|deb|emacs-defaults|1.1|all|vc/a.xml
add|dsc|emacs-defaults|1.1|all|vc/a.xml
EOF




mkdir before after

cat >before/a.xml <<EOF
<?xml version="1.0"?>
<component>
  <contents>
    <component>before/b.xml</component>
  </contents>
</component>
EOF

cat >before/b.xml <<EOF
<?xml version="1.0"?>
<component>
  <contents>
    <dsc>emacs-defaults</dsc>
  </contents>
</component>
EOF

cat >after/a.xml <<EOF
<?xml version="1.0"?>
<component>
  <contents>
    <component>after/b.xml</component>
  </contents>
</component>
EOF

cat >after/b.xml <<EOF
<?xml version="1.0"?>
<component>
  <contents>
    <dsc>emacs-defaults</dsc>
  </contents>
</component>
EOF

pdk resolve after/b.xml
pdk semdiff -m before/a.xml after/a.xml | LANG=C sort >2file.diff

diff -u - 2file.diff <<EOF
add|deb|emacs-defaults|1.1|all|after/a.xml
add|dsc|emacs-defaults|1.1|all|after/a.xml
EOF


popd
