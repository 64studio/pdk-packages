

. atest/utils/repogen-fixture.sh

set_up_repogen_fixture scary
pushd scary


    cat >scary.xml <<EOF
<?xml version="1.0"?>
<component>
  <contents>
    <deb/>
  </contents>
</component>
EOF


    pdk resolve scary.xml 2>errors.txt
    grep unoptimized errors.txt

popd
