


. atest/utils/repogen-fixture.sh

set_up_repogen_fixture download




pushd download
    rm -rf etc/cache/md5 etc/cache/sha-1
    cat >root.xml <<EOF
<component>
  <contents>
    <component>progeny.com/apache.xml</component>
    <component>progeny.com/emacs.xml</component>
  </contents>
</component>
EOF

    pdk download root.xml
    pdk repogen root.xml
popd


