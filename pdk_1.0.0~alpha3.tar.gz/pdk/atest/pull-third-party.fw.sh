


. atest/utils/repogen-fixture.sh

set_up_repogen_fixture source

pdk workspace create 3p
pdk workspace create dest


pushd dest


cat >etc/channels.xml <<EOF
<?xml version="1.0"?>
<channels>
  <source>
    <type>source</type>
    <path>$(pwd)/../source</path>
  </source>
  <third-party>
    <type>source</type>
    <path>$(pwd)/../3p</path>
  </third-party>
</channels>
EOF


popd


pushd source
    pdk add progeny.com/*.xml
    pdk download progeny.com/*.xml
    pdk commit -m "git-production commit"
popd

pushd 3p
    mkdir third-party
    echo hello >third-party/file
    pdk add third-party/file
    pdk commit -m "first third party commit"
popd




pushd dest
    pdk pull source
    echo world >some-file
    pdk add some-file
    pdk commit -m 'a local commit'
    pdk pull third-party
popd

[ -e dest/progeny.com/apache.xml ] || fail "missing third-party file"
[ -e dest/third-party/file ] || fail "missing third-party file"


