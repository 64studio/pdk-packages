# pdk-mediagen
Next-generation media generation for PDK!

# Notes
To use latest version from git with PDK:
```
sudo MEDIAGEN_PATH="/home/chris/projects/64studio/pdk-mediagen/mediagen" pdk mediagen component.xml
```
